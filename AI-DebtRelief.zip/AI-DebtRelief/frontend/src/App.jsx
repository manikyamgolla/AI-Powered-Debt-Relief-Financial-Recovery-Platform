import { Routes, Route } from "react-router-dom";
import Header from "./components/Header.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

import Landing from "./pages/Landing.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Loans from "./pages/Loans.jsx";
import LoanForm from "./pages/LoanForm.jsx";
import LoanDetails from "./pages/LoanDetails.jsx";
import Settlement from "./pages/Settlement.jsx";
import NegotiationLetter from "./pages/NegotiationLetter.jsx";
import Analytics from "./pages/Analytics.jsx";
import History from "./pages/History.jsx";
import Profile from "./pages/Profile.jsx";
import FinancialProfileForm from "./pages/FinancialProfileForm.jsx";
import NotFound from "./pages/NotFound.jsx";

export default function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/loans" element={<ProtectedRoute><Loans /></ProtectedRoute>} />
        <Route path="/loans/new" element={<ProtectedRoute><LoanForm /></ProtectedRoute>} />
        <Route path="/loans/:id" element={<ProtectedRoute><LoanDetails /></ProtectedRoute>} />
        <Route path="/loans/:id/edit" element={<ProtectedRoute><LoanForm /></ProtectedRoute>} />
        <Route path="/settlement/:loanId" element={<ProtectedRoute><Settlement /></ProtectedRoute>} />
        <Route path="/letter/:loanId" element={<ProtectedRoute><NegotiationLetter /></ProtectedRoute>} />
        <Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
        <Route path="/history" element={<ProtectedRoute><History /></ProtectedRoute>} />
        <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
        <Route path="/financial-profile" element={<ProtectedRoute><FinancialProfileForm /></ProtectedRoute>} />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
}
